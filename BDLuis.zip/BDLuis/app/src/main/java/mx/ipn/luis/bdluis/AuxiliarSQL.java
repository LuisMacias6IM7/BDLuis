package mx.ipn.luis.bdluis;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
/**
 * Created by Profesor on 08/02/2019.
 */

public class AuxiliarSQL extends SQLiteOpenHelper{

    String SQLTabla= "CREATE TABLE Reservacion ("
            +"_id INTEGER PRIMARY KEY AUTOINCREMENT, "
            +"Nombre TEXT";




    public AuxiliarSQL(Context context, String DBname,
                        CursorFactory factory,
                        int version){
        super(context,DBname, factory, version);

    }
    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
